import slider from "./carrusel.js";

const d = document;

d.addEventListener('DOMContentLoaded', ()=>{
    slider();
});