

<?php $__env->startSection('title', 'Home'); ?>

<?php $__env->startSection('content'); ?>

    <h1 class="text-center">Página de productos</h1>

    <div class="container">
    <section class="row mt-5">
    <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

        <?php
            $pId = Crypt::encrypt($product->id);
            $pCategory = $product->category;
        ?>
        <article class="col-6 col-lg-3 d-flex flex-column card-index mb-3">

            <a href="<?php echo e(route('showProduct', ['productId' => $pId, 'productCategory' => $pCategory])); ?>" class="text-reset text-decoration-none">
                <img src="/imgs/<?php echo e(isset($product->main_img) ? $product->main_img : 'default-image.jpg'); ?>" alt="imagen" class="img-card-index img-fluid"/>
                <div>
                    <h2><?php echo e($product->name); ?></h2>
                    <p><?php echo e($product->short_detail); ?></p>
                    <small>$ <b class="text-secondary text-decoration-line-through"><?php echo e($product->old_price); ?></b> ARS</small>
                    <small class="fs-5">$ <b class="text-warning-emphasis"><?php echo e($product->current_price); ?></b> ARS</small>
                    <p class="mt-2 btn btn-warning fw-regular text-secondary-emphasis">Agregar al carrito</p>
                </div>
            </a>
        
        </article>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <p class="ps-5">No hay productos cargados en el sistema</p> 
    <?php endif; ?>

    </section>

        <div class="d-flex flex-column justify-content-center align-items-center my-5 color-success">
            <?php echo e($products->links('pagination::bootstrap-5')); ?>  
        </div>

        
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\larabel\simonaEcommerce\resources\views/productos.blade.php ENDPATH**/ ?>