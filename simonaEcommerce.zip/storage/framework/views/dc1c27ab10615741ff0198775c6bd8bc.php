

<?php $__env->startSection('title', 'Home'); ?>

<?php $__env->startSection('content'); ?>

    <h1 class="text-center">Página de productos filtrados por marca y prenda</h1>

    <?php $__currentLoopData = $productosFiltrados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productFiltrado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <p>Prenda: <?php echo e($productFiltrado->product); ?> | marca: <?php echo e($productFiltrado->brand); ?> </p>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\larabel\simonaEcommerce\resources\views/productosFiltrados.blade.php ENDPATH**/ ?>