

<?php $__env->startSection('title', 'Home'); ?>

<?php $__env->startSection('content'); ?>

    <h1 class="text-center">Filtrado por <?php echo e($valor); ?></h1>

    <?php $__currentLoopData = $productosFiltrados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productFiltrado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
        <?php
        $pId = Crypt::encrypt($productFiltrado->id);
        $pCategory = $productFiltrado->category;
      ?>
      <a href="<?php echo e(route('showProduct', ['productId' => $pId , 'productCategory' => $pCategory])); ?>" class="text-reset text-decoration-none">
        <section class="m-auto row bg-light shadow border rounded my-3 height-filter-card">
          
          <div class="col-12 col-sm-4">
            <img src="/imgs/<?php echo e($productFiltrado->main_img); ?>" alt="img-searched" class="img-fluid height-filter-card" />
          </div>
          <div class="col-12 col-sm-8 d-flex flex-column justify-content-between">
            <div>
                <h3 class="pt-3"><?php echo e($productFiltrado->name); ?></h3>
                <p><?php echo e($productFiltrado->short_detail); ?></p>
                <p><b>Filtro:</b> <small class="badge text-bg-primary"><?php echo e($productFiltrado->product); ?></small></p>
                <div>
                    <small>$ <b class="text-secondary text-decoration-line-through"><?php echo e($productFiltrado->old_price); ?></b> ARS</small>
                    <small class="fs-5">$ <b class="text-warning-emphasis"><?php echo e($productFiltrado->current_price); ?></b> ARS</small>
                </div>
            </div>
            <p class="mt-2 btn btn-warning fw-regular text-secondary-emphasis">Agregar al carrito</p>
          </div>
          
        </section>
      </a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\larabel\simonaEcommerce\resources\views/productosFiltrados.blade.php ENDPATH**/ ?>