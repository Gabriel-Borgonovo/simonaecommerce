

<?php $__env->startSection('title', 'Home'); ?>

<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('_components.portada', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <div class="container min-vh-100 mt-5">
        <h1 class="text-center">Página de Inicio</h1>
        <section class="row">
            <article class="col-12 col-lg-3 my-5">
                <div class="border rounded shadow bg-ligth">
                    <h2 class="text-center">Filtros</h2>
                    <div class="ps-5">
                        <h3 class="fw-normal fs-5">Por prendas</h3>
                            <div>
                                <a href=""><span class="badge rounded-pill text-bg-secondary">Sweeter</span></a>
                                <a href=""><span class="badge rounded-pill text-bg-secondary">Pantalones</span></a>
                                <a href=""><span class="badge rounded-pill text-bg-secondary">Camisas</span></a>
                                <a href=""><span class="badge rounded-pill text-bg-secondary">Zapatos</span></a>
                                <a href=""><span class="badge rounded-pill text-bg-secondary">Vestidos</span></a>
                            </div>
                        <h3 class="fw-normal fs-5 mt-5">Por marcas</h3>
                        <div class="mb-5">
                            <a href=""><span class="badge rounded-pill text-bg-secondary">Nike</span></a>
                            <a href=""><span class="badge rounded-pill text-bg-secondary">Solido</span></a>
                            <a href=""><span class="badge rounded-pill text-bg-secondary">Bando</span></a>
                            <a href=""><span class="badge rounded-pill text-bg-secondary">A+</span></a>
                            <a href=""><span class="badge rounded-pill text-bg-secondary">Adidas</span></a>
                        </div>
                    </div> 
                </div> 
            </article>

            
            <div class="col-12 col-lg-9 my-5">
               <div class="bg-ligth border rounded shadow row">
                    <h2 class="text-center">Productos</h2>
                    <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <article class="col-6 col-lg-3 d-flex flex-column card-index mb-3">

                            <?php
                                // Decode the detail_imgs JSON string into an array
                                $detailImgs = json_decode($product->detail_imgs, true);
                                $pId = Crypt::encrypt($product->id);
                                $pCategory = $product->category;
                            ?>

                            <a href="<?php echo e(route('showProduct', ['productId' => $pId, 'productCategory' => $pCategory])); ?>" class="text-reset text-decoration-none">
                                <div class="position-relative">
                                    <img src="/imgs/<?php echo e(isset($product->main_img) ? $product->main_img : 'default-image.jpg'); ?>" alt="imagen" class="img-card-index img-fluid"/>
                                    <div class="triangle-offer bg-danger text-light">-<?php echo e(intval($product->discount)); ?>% OFF</div>
                                </div>
                            
                                <div class="d-flex flex-column">
                                    <h5><?php echo e($product->name); ?></h5>
                                    <p class="fs-small"><?php echo e($product->short_detail); ?></p>
                                    <small>$ <b class="text-secondary text-decoration-line-through"><?php echo e($product->old_price); ?></b> ARS</small>
                                    <small class="fs-5">$ <b class="text-warning-emphasis"><?php echo e($product->current_price); ?></b> ARS</small>
                                    <p class="mt-2 btn btn-warning fw-regular text-secondary-emphasis">Agregar al carrito</p>
                                </div>
                            </a>
                        </article>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="ps-5">No hay productos cargados en el sistema</p> 
                    <?php endif; ?>
                </div> 
            </div>
        
        </section>
    </div>
    

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\larabel\simonaEcommerce\resources\views/index.blade.php ENDPATH**/ ?>