<div class="min-vh-50 bg-dark mt-5 d-flex flex-column justify-content-between align-items-center pb-3">
    <section class="d-flex justify-content-center gap-5 mt-5 flex-wrap">
    <div class="text-light">
        <h2 class="fs-4 text-warning">Links del sitio web</h2>
        <ul class="ls-none">
            <li><a href="<?php echo e(route('index')); ?>" class="text-reset text-decoration-none">Home</a></li>
            <li><a href="<?php echo e(route('productos')); ?>" class="text-reset text-decoration-none">Productos</a></li>
            <li><a href="<?php echo e(route('nosotros')); ?>" class="text-reset text-decoration-none">Nosotros</a></li>
           
        </ul>
    </div>

    <div class="text-light">
        <h2 class="fs-4 text-warning">Redes</h2>
        <ul class="ls-none">
            <li><a href="<?php echo e(route('index')); ?>" class="text-reset text-decoration-none"><i class="bi bi-facebook fs-3"></i></a></li>
            <li><a href="<?php echo e(route('productos')); ?>" class="text-reset text-decoration-none"><i class="bi bi-instagram fs-3"></i></a></li>
        </ul>
    </div>

    <div class="text-light" id="contacto-data">
        <h2 class="fs-4 text-warning">Contacto</h2>
        <button class="btn btn-success">Enviar Whatsapp</button>
    </div>

    </section>
    <div>
        <small class="text-light">&copy; Página diseñada por Gabriel Alejandro Borgonovo</small>
    </div>
</div><?php /**PATH C:\xampp\htdocs\larabel\simonaEcommerce\resources\views/layouts/_partials/footer.blade.php ENDPATH**/ ?>