

<?php $__env->startSection('title', 'Home'); ?>

<?php $__env->startSection('content'); ?>

    <div class="min-vh-100">
       <h1 class="text-center">Página de contacto</h1> 
    </div>
    

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\larabel\simonaEcommerce\resources\views/contacto.blade.php ENDPATH**/ ?>