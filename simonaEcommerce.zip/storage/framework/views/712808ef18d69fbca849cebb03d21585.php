

<?php $__env->startSection('title', 'Productos'); ?>

<?php $__env->startSection('content'); ?>

  <?php if(isset($searchQuery)): ?>
    <h1 class="fs-5 text-center fw-normal text-secondary mt-5">Resultados de: "<b><?php echo e($searchQuery); ?></b>"</h1>

    <?php if($products->isEmpty()): ?>
      <div class="min-vh-50 d-flex flex-column justify-content-center justify-content-lg-start align-items-center">
        <div class="mt-5 text-center overflow-hidden">
          
          <div class="p-2 animation-move">
            <img src="/imgs/alert.svg" alt="logo" class="img-fluid icon-alert">
            <h2 class="fw-normal fs-5 text-secondary">No se encontraron productos con: "<?php echo e($searchQuery); ?>"</h2>
          </div>
          
          <a href="<?php echo e(route('index')); ?>" class="btn btn-warning mt-5">Volver</a>
        </div>
      </div>
      
    <?php else: ?>
      <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <?php
          $pId = Crypt::encrypt($product->id);
          $pCategory = $product->category;
        ?>
        <a href="<?php echo e(route('showProduct', ['productId' => $pId , 'productCategory' => $pCategory])); ?>" class="text-reset text-decoration-none">
          <section class="m-auto row bg-light shadow border rounded my-3">
            
            <div class="col-12 col-sm-4">
              <img src="/imgs/<?php echo e($product->main_img); ?>" alt="img-searched" class="img-fluid" />
            </div>
            <div class="col-12 col-sm-8">
              <h3 class="pt-3"><?php echo e($product->name); ?></h3>
              <p><?php echo e($product->short_detail); ?></p>
              <div>
                <small>$ <b class="text-secondary text-decoration-line-through"><?php echo e($product->old_price); ?></b> ARS</small>
                <small class="fs-5">$ <b class="text-warning-emphasis"><?php echo e($product->current_price); ?></b> ARS</small>
              </div>
              <p class="mt-2 btn btn-warning fw-regular text-secondary-emphasis">Agregar al carrito</p>
            </div>
            
          </section>
        </a>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <div class="d-flex flex-column justify-content-center align-items-center my-5 color-success">
          <?php echo e($products->links('pagination::bootstrap-5')); ?>  
        </div> 
    <?php endif; ?>

  <?php else: ?>
    <h1>Todos los productos</h1>

    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <?php echo e($products->links()); ?>  <?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\larabel\simonaEcommerce\resources\views/busqueda.blade.php ENDPATH**/ ?>