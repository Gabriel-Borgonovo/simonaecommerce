<div class="border-bottom">
  <div class="buscador container py-2">
    <form action="<?php echo e(route('search')); ?>" method="GET">
      <input type="text" name="busqueda" placeholder="Buscar productos..." />
      <button type="submit" class="btn btn-primary">Buscar</button>
    </form>
  </div>
</div><?php /**PATH C:\xampp\htdocs\larabel\simonaEcommerce\resources\views/layouts/_partials/buscador.blade.php ENDPATH**/ ?>