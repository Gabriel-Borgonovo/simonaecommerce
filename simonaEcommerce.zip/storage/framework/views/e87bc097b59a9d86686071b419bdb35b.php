

<?php $__env->startSection('name', '<?php echo e($product->name); ?>'); ?>

<?php $__env->startSection('title', 'Home'); ?>

<?php
    // Decode the detail_imgs JSON string into an array
    $detailImgs = json_decode($product->detail_imgs, true);
    $colors = json_decode($product->colors, true);
?>

<?php $__env->startSection('content'); ?>

<div class="container">
    
    <div class="row my-5">
        <section class="col-12 col-lg-7 row img-detail-grid row">

            <div class="col-12 col-lg-3 js-imgs gap-3 gap-lg-2 order-2 order-lg-0 d-flex flex-row flex-lg-column mt-3 mt-lg-0 flex-wrap">

                <?php $__currentLoopData = $detailImgs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <img src="/imgs/<?php echo e($img); ?>" alt="imagen" class="img-mini<?php echo e($index === 0 ? ' img-active' : ''); ?>" />
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <div class="main-img-detail col-12 col-lg-9 js-main-img overflow-hidden rounded shadow">
                <img src="/imgs/<?php echo e($product->main_img); ?>" alt="imagen" class="img-fluid img-main" />
            </div>
            
        </section>
        <section class="col-12 col-lg-5 position-relative pt-5 p-lg-0">
            <h1 class="px-3"><?php echo e($product->name); ?></h1>
            <p class="px-3"><?php echo e($product->complete_detail); ?></p>
            <p class="px-3"><span><b>Talles:</b> <?php echo e($product->size); ?></span> <span class="ps-3"><b>Marca:</b> <?php echo e($product->brand); ?></span></p>
            <p class="px-3"><b>Colores disponibles:</b>
            <?php $__currentLoopData = $colors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
             <?php echo e($color); ?> |
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </p>
            <p class="px-3"><b>Stock:</b> <?php echo e($product->stock); ?></p>
            <p class="px-3">Precio anterior: $ <?php echo e($product->old_price); ?></p>
            <p class="px-3 fs-2 fw-bold">$ <?php echo e($product->current_price); ?> <small class="text-danger fs-5">%<?php echo e(intval($product->discount)); ?> OFF</small></p>
            <button class="px-3 btn btn-success" onclick="enviarMensaje()">Comprar producto</button>
            
            <div class="d-flex flex-column justify-content-end position-absolute bottom-0 top-lg-0 end-0 p-2 bg-light rounded shadow">
                <h3 class="title-share-btns">Compartir</h3>
                <?php
                    $pId = Crypt::encrypt($product->id);
                    $pCategory = $product->category;
                    $whatsapp_message = $product->name . ' - ' . route('showProduct', ['productId' => $pId, 'productCategory' => $pCategory]);
                    $encoded_whatsapp_message = rawurlencode($whatsapp_message);
                    $image_url = 'https://modasimona.mi-rio2.com/imgs/' . $product->main_img; 
                    $encoded_image_url = urlencode($image_url);
                ?>

                <a href="whatsapp://send?text=<?php echo e($encoded_whatsapp_message); ?>&?image=<?php echo e($encoded_image_url); ?>" data-action="share/whatsapp/share" class="btn text-reset d-flex flex-column justify-content-center align-items-center p-1">
                    <img src="/imgs/whatsapp.svg" alt="icono whatsapp" class="icono-share-width p-0">
                    <span class="text-share-btns p-0">Whatsapp</span>
                </a>

                
                <a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo e(route('showProduct', ['productId' => $pId, 'productCategory' => $pCategory])); ?>" target="_blank" class="btn text-reset d-flex flex-column justify-content-center align-items-center p-1">
                    <img src="/imgs/facebook.svg" alt="icono whatsapp" class="icono-share-width p-0">
                    <span class="text-share-btns p-0">Facebook</span>
                </a>

            </div>
        </section>
    </div>


    
    <h2 class="text-center mt-5">Productos relacionados</h2>
    <section class="mt-3 d-flex justify-content-center align-items-center width-related-products position-relative">

         
         <div class="btns-related-products">
            <img src="/imgs/chevron-left.svg" alt="izquierda" id="left">
            <img src="/imgs/chevron-rigth.svg" alt="derecha" id="right">
        </div>
        <div class="wrapper">
            
        <ul class="carousel" >
        <?php $__empty_1 = true; $__currentLoopData = $relatedProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

           

            <li class="card">
                <a href="<?php echo e(route('showProduct', ['productId' => Crypt::encrypt($product2->id), 'productCategory' => $product->category])); ?>" class="text-reset text-decoration-none">
                <div class="img">
                    <img src="/imgs/<?php echo e($product2->main_img); ?>" alt="imagen carrousel" draggable="false">
                </div>
                <div>
                    <h2><?php echo e($product2->name); ?></h2>
                    <p><?php echo e($product2->short_detail); ?></p>
                    <span>Categoría: <b><?php echo e($product2->category); ?></b></span>
                </div>
                </a>
            </li>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <li>No se encontraron productos relacionados.</li>
        <?php endif; ?>
        </ul>
        
        </div>
    </section>
</div>

<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(asset('assets/js/detailImgs.js')); ?>" ></script>
    <script src="<?php echo e(asset('assets/js/cardCarrousel.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>



<script>
    function enviarMensaje() {
        // Obtener el nombre del producto y la imagen
        let nombreProducto = "<?php echo e($product->name); ?>";
        let urlProducto = "<?php echo e(route('showProduct', ['productId' => $product->id, 'productCategory' => $product->category])); ?>";
    
        // Crear el mensaje de WhatsApp con el enlace al producto
        let mensaje = "¡Hola! Estoy interesado en comprar el producto '" + nombreProducto + "'.";
        mensaje += " Puedes ver más detalles y comprarlo aquí: " + urlProducto;
    
        // Codificar el mensaje para que se pueda enviar correctamente en la URL
        let mensajeCodificado = encodeURIComponent(mensaje);
    
        // Abrir la ventana de chat de WhatsApp con el mensaje predefinido
        window.open("https://wa.me/3572591668/?text=" + mensajeCodificado, "_blank");
    }
</script>


<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\larabel\simonaEcommerce\resources\views/showProduct.blade.php ENDPATH**/ ?>