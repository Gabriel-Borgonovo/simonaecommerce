@extends('layouts.plantilla')

@section('title', 'Home')

@section('content')

    <h1 class="text-center">Página de contacto</h1>

@endsection