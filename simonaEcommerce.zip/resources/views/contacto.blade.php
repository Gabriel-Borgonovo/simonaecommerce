@extends('layouts.plantilla')

@section('title', 'Home')

@section('content')

    <div class="min-vh-100">
       <h1 class="text-center">Página de contacto</h1> 
    </div>
    

@endsection