@extends('layouts.plantilla')

@section('title', 'Home')

@section('content')

    <h1 class="text-center">Página de productos filtrados por marca y prenda</h1>

    @foreach ($productosFiltrados as $productFiltrado)
        <p>Prenda: {{ $productFiltrado->product }} | marca: {{ $productFiltrado->brand }} </p>
    @endforeach
@endsection